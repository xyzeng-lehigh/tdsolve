prob_id  = 0
lambda   = 0.45
mu       = 0.33
delta    = 0.48
alpha    = 0.015
theta    = 1.0e+6
n_bc     = 5.0e-3
delta_n  = 1.0
D       = 6.048
// m in [7 170] x 10^4
m       = VALM
beta    = 1.0e+5
// gamma in [0.17 4.2] x 10^2
gamma   = 1.0e+2


ic            = 0
r_0           = 0.2
Nx            = 50
A_Multiplier  = 3
cfl           = 0.4
Tinit         = 0.0
Tterm         = 80.0
Tfreq         = 0.02
time_method   = 1
max_iter      = 10000000
dt_init       = 1.0e-6
dt_growth     = 1.2

framework   = 1
space_cell  = 0
space_chem  = 0
vel         = 0

lsysType  = DIR
lsysPrint = 0

outputDataFile  = sol.dat
radiusDataFile  = rad.dat

