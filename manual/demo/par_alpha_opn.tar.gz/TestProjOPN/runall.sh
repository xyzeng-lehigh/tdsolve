for alpha in 0.4 0.5 0.6 0.7
do
  sed "s/VALALPHA/${alpha}/g" input_raw.hcl > input.hcl
  ./run_1.sh
  cp report data/report_alpha${alpha}.txt
  cp rad.dat data/rad_alpha${alpha}.dat
  cp sol.dat data/sol_alpha${alpha}.dat
done
