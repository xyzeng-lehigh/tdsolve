alpha=$1

proj=run_alpha${alpha}

if [ -d "$proj" ];
then
  rm -rf ${proj}
fi

mkdir ${proj}
cd ${proj}
cp ../run_2.sh ./
cp ../input_raw.hcl ./

sed "s/VALALPHA/${alpha}/g" input_raw.hcl > input.hcl
./run_2.sh
cp report ../data/report_alpha${alpha}.txt
cp rad.dat ../data/rad_alpha${alpha}.dat
cp sol.dat ../data/sol_alpha${alpha}.dat
cd ../
