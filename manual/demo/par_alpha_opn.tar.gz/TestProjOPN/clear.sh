rm rad.dat
rm report
rm sol.dat
rm input.hcl
