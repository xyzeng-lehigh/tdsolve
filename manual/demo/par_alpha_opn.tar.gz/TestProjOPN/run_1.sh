../../TDSolve/TumorDynRun -i input.hcl 2>&1 |tee report
