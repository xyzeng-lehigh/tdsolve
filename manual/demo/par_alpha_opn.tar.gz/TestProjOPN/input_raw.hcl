prob_id  = 1
lambda   = 0.48
// mu in [0.33 0.38]
mu       = 0.33
delta_1  = 0.45
D_3      = 6.048
// alpha_3 in [0.7 17] x 10^5
alpha_3  = 0.7e+5
beta_3   = 1.0e+5
// gamma_3 in [17 420]
gamma_3  = 17.0
alpha    = VALALPHA
delta_2  = 0.9
theta    = 1.0e+6
a        = 100.0
b        = 100.0
// D_1, D_2 in [0.00038 0.0216], default 0.01
D_1      = 0.01
D_2      = 0.01
alpha_1  = 2.0
alpha_2  = 2.0
beta_1   = 100.0
beta_2   = 100.0
gamma_1  = 0.01
gamma_2  = 0.01
a_prime  = 0.1
b_prime  = 0.1
n_bc     = 5.0e-3

ic            = 0
r_0           = 0.2
Nx            = 50
A_Multiplier  = 3
cfl           = 0.4
Tinit         = 0.0
Tterm         = 60.0
Tfreq         = 0.02
time_method   = 1
max_iter      = 10000000
dt_init       = 1.0e-6
dt_growth     = 1.2

framework   = 1
space_cell  = 2
space_chem  = 1
vel         = 0

lsysType  = DIR
lsysPrint = 0

outputDataFile  = sol.dat
radiusDataFile  = rad.dat

