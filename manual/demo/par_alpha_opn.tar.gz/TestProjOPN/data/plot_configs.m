curve_lwdth = 4;
sline_lwdth = 2;
label_fsize = 24;
title_fsize = 36;
legen_fsize = 24;
texts_fsize = legen_fsize;

g_ratio = (sqrt(5)-1)/2;

default_fspeed = 1;
frate          = 30;
