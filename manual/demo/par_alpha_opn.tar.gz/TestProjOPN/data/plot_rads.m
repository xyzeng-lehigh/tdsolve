
alphaval = {'1e+5', '2e+5', '4e+5', '8e+5'};

Nalpha = length( alphaval );
target_rad = 6.0;

alphaspec = {'b-', 'g-', 'm-', 'r-'};

save_file_name = 'radius_growth.eps';

xrange = [0 60];

for nalpha = 1 : Nalpha
  rad_file = ['rad_alpha' alphaval{nalpha} '.dat'];
  rads{nalpha} = load(rad_file);
  desc{nalpha} = ['\alpha=' alphaval{nalpha}];
end

plot_configs;

scrsz = get(0,'ScreenSize');
figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]);
hold on;

for nalpha = 1 :Nalpha
  data = rads{nalpha};
  plot( data(:,1), data(:,2), alphaspec{nalpha}, 'LineWidth', curve_lwdth );
  xlim(xrange);

  % Find the date when the radius reaches target value
  idx_r = find( data(:,2)>=target_rad, 1 );
  idx_l = idx_r-1;
  coef_l = (data(idx_r,2)-target_rad)/(data(idx_r,2)-data(idx_l,2));
  coef_r = (target_rad-data(idx_l,2))/(data(idx_r,2)-data(idx_l,2));
  t_date{nalpha} = coef_l * data(idx_l,1) + coef_r * data(idx_r,1);
  desc{nalpha} = [desc{nalpha} '; ' sprintf('%1.1f',target_rad) 'mm date: ' sprintf('%2.1f', t_date{nalpha}), ' days.'];
end
leg = legend( desc, 'Location', 'NW' );
set( leg, 'FontSize', legen_fsize );
title( 'Radius growth starting at 0.2mm', 'FontSize', title_fsize );
xlab = xlabel('Days');
ylab = ylabel('Radius (mm)');
set( xlab, 'FontSize', label_fsize );
set( ylab, 'FontSize', label_fsize );

plot( xrange, [target_rad target_rad], 'k--', 'LineWidth', sline_lwdth );
text( g_ratio*xrange(1) + (1-g_ratio)*xrange(2), target_rad, [sprintf('%1.1f',target_rad) 'mm'], ...
      'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', 'FontSize', texts_fsize );
for nalpha = 1 : Nalpha
  plot( [t_date{nalpha} t_date{nalpha}], [0 target_rad], 'k--', 'LineWidth', sline_lwdth );
  text( t_date{nalpha}, 0, [sprintf('%2.1f', t_date{nalpha})], 'HorizontalAlignment', 'right', ...
        'VerticalAlignment', 'bottom', 'FontSize', texts_fsize, 'color', alphaspec{nalpha}(1));
end

saveas(gca, save_file_name, 'epsc');
