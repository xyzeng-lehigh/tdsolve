% Remember to set $HCL as the HCLSolve path in ~/.bash_profile
beep off;
addpath('../../../TDSolve/tools');
