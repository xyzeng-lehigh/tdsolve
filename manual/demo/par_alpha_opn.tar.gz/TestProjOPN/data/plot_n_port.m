
alphaval = {'0.4', '0.5', '0.6', '0.7'};

Nalpha = length( alphaval );
target_rad = 6.0;

alphaspec = {'b-', 'g-', 'm-', 'r-'};

plot_configs;

save_file_name = 'n_percentage.eps';

xrange = [0 60];

for nalpha = 1 : Nalpha
  sol_file = ['sol_alpha' alphaval{nalpha} '.dat'];
  data_all{nalpha}= proc_voldata_fvm_1d_tumordyn(1,sol_file);
  legs{nalpha} = ['\alpha=' alphaval{nalpha}];

  rad_file = ['rad_alpha' alphaval{nalpha} '.dat'];
  data = load(rad_file);
  idx_r = find( data(:,2)>=target_rad, 1 );
  idx_l = idx_r-1;
  coef_l = (data(idx_r,2)-target_rad)/(data(idx_r,2)-data(idx_l,2));
  coef_r = (target_rad-data(idx_l,2))/(data(idx_r,2)-data(idx_l,2));
  t_date{nalpha} = coef_l * data(idx_l,1) + coef_r * data(idx_r,1);

  time = data_all{nalpha}(:,1);
  t_idx = find(time>t_date{nalpha},1);
  time_r = time(t_idx);
  time_l = time(t_idx-1);
  coef_l = (time_r-t_date{nalpha})/(time_r-time_l);
  coef_r = (t_date{nalpha}-time_l)/(time_r-time_l);
  data_l = data_all{nalpha}(t_idx-1,8);
  data_r = data_all{nalpha}(t_idx,  8);
  n_port{nalpha} = coef_l * data_l + coef_r * data_r;
end

scrsz = get(0,'ScreenSize');
figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]);
hold on;
for nalpha = 1 : Nalpha
  data = data_all{nalpha};
  plot( data(:,1), data(:,8), alphaspec{nalpha}, 'LineWidth', curve_lwdth );
  xlim(xrange);
end
leg = legend( legs, 'Location', 'NE' );
set( leg, 'FontSize', legen_fsize );
title( 'Immune cell (N) percentage', 'FontSize', title_fsize );
xlab = xlabel('Days');
ylab = ylabel('Percentage of N');
set( xlab, 'FontSize', label_fsize );
set( ylab, 'FontSize', label_fsize );

for nalpha = 1 : Nalpha
  plot( [0 t_date{nalpha} t_date{nalpha}], [n_port{nalpha} n_port{nalpha} 0], 'k--', 'LineWidth', sline_lwdth );
  text( t_date{nalpha}, 0, [sprintf('%2.1f', t_date{nalpha})], 'HorizontalAlignment', 'right', ...
        'VerticalAlignment', 'bottom', 'FontSize', texts_fsize, 'color', alphaspec{nalpha}(1));
  text( (1-g_ratio)*t_date{nalpha}, n_port{nalpha}, [sprintf('%2.1f%%', 100*n_port{nalpha})], 'HorizontalAlignment', 'left', ...
        'VerticalAlignment', 'bottom', 'FontSize', texts_fsize, 'color', alphaspec{nalpha}(1));
end
ylim([0.9 1]);

saveas( gca, save_file_name, 'epsc' );
