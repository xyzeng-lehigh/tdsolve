
mval = {'1e+5', '2e+5', '4e+5', '8e+5'};

Nm = length( mval );
target_rad = 6.0;

mspec = {'b-', 'g-', 'm-', 'r-'};

save_file_name = 'radius_growth.eps';

xrange = [0 75];

for nm = 1 : Nm
  rad_file = ['rad_m' mval{nm} '.dat'];
  rads{nm} = load(rad_file);
  desc{nm} = ['m=' mval{nm}];
end

plot_configs;

scrsz = get(0,'ScreenSize');
figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]);
hold on;

for nm = 1 :Nm 
  data = rads{nm};
  plot( data(:,1), data(:,2), mspec{nm}, 'LineWidth', curve_lwdth );
  xlim(xrange);

  % Find the date when the radius reaches target value
  idx_r = find( data(:,2)>=target_rad, 1 );
  idx_l = idx_r-1;
  coef_l = (data(idx_r,2)-target_rad)/(data(idx_r,2)-data(idx_l,2));
  coef_r = (target_rad-data(idx_l,2))/(data(idx_r,2)-data(idx_l,2));
  t_date{nm} = coef_l * data(idx_l,1) + coef_r * data(idx_r,1);
  desc{nm} = [desc{nm} '; ' sprintf('%1.1f',target_rad) 'mm date: ' sprintf('%2.1f', t_date{nm}), ' days.'];
end
leg = legend( desc, 'Location', 'NW' );
set( leg, 'FontSize', legen_fsize );
title( 'Radius growth starting at 0.2mm', 'FontSize', title_fsize );
xlab = xlabel('Days');
ylab = ylabel('Radius (mm)');
set( xlab, 'FontSize', label_fsize );
set( ylab, 'FontSize', label_fsize );

plot( xrange, [target_rad target_rad], 'k--', 'LineWidth', sline_lwdth );
text( g_ratio*xrange(1) + (1-g_ratio)*xrange(2), target_rad, [sprintf('%1.1f',target_rad) 'mm'], ...
      'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', 'FontSize', texts_fsize );
for nm = 1 : Nm
  plot( [t_date{nm} t_date{nm}], [0 target_rad], 'k--', 'LineWidth', sline_lwdth );
  text( t_date{nm}, 0, [sprintf('%2.1f', t_date{nm})], 'HorizontalAlignment', 'right', ...
        'VerticalAlignment', 'bottom', 'FontSize', texts_fsize, 'color', mspec{nm}(1));
end

saveas(gca, save_file_name, 'epsc');
