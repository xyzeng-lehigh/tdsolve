
mval = {'1e+5', '2e+5', '4e+5', '8e+5'};

Nm = length( mval );
target_rad = 6.0;

mspec = {'b-', 'g-', 'm-', 'r-'};

plot_configs;

save_file_name = 'n_percentage.eps';

xrange = [0 75];

for nm = 1 : Nm
  sol_file = ['sol_m' mval{nm} '.dat'];
  [data_all{nm}, time] = proc_voldata_fvm_1d_tumordyn(sol_file);
  legs{nm} = ['m=' mval{nm}];

  rad_file = ['rad_m' mval{nm} '.dat'];
  data = load(rad_file);
  idx_r = find( data(:,2)>=target_rad, 1 );
  idx_l = idx_r-1;
  coef_l = (data(idx_r,2)-target_rad)/(data(idx_r,2)-data(idx_l,2));
  coef_r = (target_rad-data(idx_l,2))/(data(idx_r,2)-data(idx_l,2));
  t_date{nm} = coef_l * data(idx_l,1) + coef_r * data(idx_r,1);

  t_idx = find(time>t_date{nm},1);
  time_r = time(t_idx);
  time_l = time(t_idx-1);
  coef_l = (time_r-t_date{nm})/(time_r-time_l);
  coef_r = (t_date{nm}-time_l)/(time_r-time_l);
  data_l = data_all{nm}(t_idx-1,8);
  data_r = data_all{nm}(t_idx,  8);
  n_port{nm} = coef_l * data_l + coef_r * data_r;
end

scrsz = get(0,'ScreenSize');
figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]);
hold on;
for nm = 1 : Nm
  data = data_all{nm};
  plot( data(:,1), data(:,8), mspec{nm}, 'LineWidth', curve_lwdth );
  xlim(xrange);
end
leg = legend( legs, 'Location', 'NE' );
set( leg, 'FontSize', legen_fsize );
title( 'Immune cell (N) percentage', 'FontSize', title_fsize );
xlab = xlabel('Days');
ylab = ylabel('Percentage of N');
set( xlab, 'FontSize', label_fsize );
set( ylab, 'FontSize', label_fsize );

for nm = 1 : Nm
  plot( [0 t_date{nm} t_date{nm}], [n_port{nm} n_port{nm} 0], 'k--', 'LineWidth', sline_lwdth );
  text( t_date{nm}, 0, [sprintf('%2.1f', t_date{nm})], 'HorizontalAlignment', 'right', ...
        'VerticalAlignment', 'bottom', 'FontSize', texts_fsize, 'color', mspec{nm}(1));
  text( (1-g_ratio)*t_date{nm}, n_port{nm}, [sprintf('%2.1f%%', 100*n_port{nm})], 'HorizontalAlignment', 'left', ...
        'VerticalAlignment', 'bottom', 'FontSize', texts_fsize, 'color', mspec{nm}(1));
end

saveas( gca, save_file_name, 'epsc' );
