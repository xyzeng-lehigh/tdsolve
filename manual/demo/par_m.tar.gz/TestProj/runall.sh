for m in 1e+5 2e+5 4e+5 8e+5
do
  sed "s/VALM/${m}/g" input_raw.hcl > input.hcl
  ./run_1.sh
  cp report data/report_m${m}.txt
  cp rad.dat data/rad_m${m}.dat
  cp sol.dat data/sol_m${m}.dat
done
