m=$1

proj=run_m${m}

if [ -d "$proj" ];
then
  rm -rf ${proj}
fi

mkdir ${proj}
cd ${proj}
cp ../run_2.sh ./
cp ../input_raw.hcl ./

sed "s/VALM/${m}/g" input_raw.hcl > input.hcl
./run_2.sh
cp report ../data/report_m${m}.txt
cp rad.dat ../data/rad_m${m}.dat
cp sol.dat ../data/sol_m${m}.dat
cd ../
